"""
Discord bot commands for the social media simulation.
Contains all user-facing commands and their implementations.
"""

import discord
from discord.ext import commands
import re
import os
from data_manager import DataManager
from social_simulator import SocialSimulator

# Initialize data manager
data_manager = DataManager()

# Global flag to prevent duplicate setups
_commands_registered = False

def setup_commands(bot):
    """Setup all bot commands."""
    global _commands_registered
    
    # Prevent duplicate command registration
    if _commands_registered:
        print("Commands already registered, skipping...")
        return
    
    print("Registering bot commands...")
    _commands_registered = True
    
    @bot.command(name='post')
    @commands.cooldown(1, 3, commands.BucketType.user)  # 1 use per 3 seconds per user
    async def post_command(ctx, *, content):
        # Prevent duplicate processing
        if ctx.message.id in bot._processing_commands:
            return
        bot._processing_commands.add(ctx.message.id)
        """
        Create a social media post and simulate its performance.
        
        Usage: !post <your content here>
        """
        if len(content) > 2000:
            await ctx.send("❌ Post content is too long! Please keep it under 2000 characters.")
            return
        
        if len(content.strip()) < 5:
            await ctx.send("❌ Your post is too short! Please write at least 5 characters.")
            return
        
        user_id = str(ctx.author.id)
        post_id = str(data_manager.get_total_posts() + 1)
        
        # Get current user data
        user_data = data_manager.get_user_data(user_id)
        current_followers = user_data["followers"]
        
        # Simulate post performance
        performance = SocialSimulator.simulate_post_performance(content, current_followers)
        
        # Create post in database
        post_data = data_manager.create_post(
            post_id=post_id,
            author_id=user_id,
            content=content,
            likes=performance['likes'],
            shares=performance['shares'],
            comments=performance['comments'],
            rating=performance['rating'],
            followers_gain=performance['followers_gain'],
            viral_type=performance['viral_type']
        )
        
        # Save data - ensure this always works
        if not data_manager.save_data():
            await ctx.send("⚠️ Warning: Could not save your post data.")
            bot._processing_commands.discard(ctx.message.id)
            return
        
        # Create embed response with different colors and titles for viral types
        if performance['viral_type'] == 'mega_viral':
            embed_color = discord.Color.purple()
            title_suffix = " 🌟 MEGA VIRAL! 🌟"
        elif performance['viral_type'] == 'viral':
            embed_color = discord.Color.red()
            title_suffix = " 🔥 VIRAL!"
        else:
            embed_color = discord.Color.blue()
            title_suffix = ""
        
        embed = discord.Embed(
            title=f"📱 Your Post{title_suffix}",
            description=f"*{content[:1500]}{'...' if len(content) > 1500 else ''}*",
            color=embed_color
        )
        
        # Set author with avatar
        if ctx.author.avatar:
            embed.set_author(name=ctx.author.display_name, icon_url=ctx.author.avatar.url)
        else:
            embed.set_author(name=ctx.author.display_name)
        
        # Add performance metrics
        embed.add_field(name="📊 Post Rating", value=f"{performance['rating']}/1.0", inline=True)
        embed.add_field(name="👍 Likes", value=f"{performance['likes']:,}", inline=True)
        embed.add_field(name="🔄 Shares", value=f"{performance['shares']:,}", inline=True)
        
        # Add followers info
        new_total = user_data["followers"]
        embed.add_field(name="👥 Followers Gained", value=f"+{performance['followers_gain']:,}", inline=True)
        embed.add_field(name="👥 Total Followers", value=f"{new_total:,}", inline=True)
        
        # Add viral indicator
        if performance['viral_type'] == 'mega_viral':
            embed.add_field(name="🌟 Status", value="**MEGA VIRAL POST!**\n*Ultra rare! 0.2% chance!*", inline=True)
        elif performance['viral_type'] == 'viral':
            embed.add_field(name="🔥 Status", value="**VIRAL POST!**\n*Rare! 2% chance!*", inline=True)
        else:
            embed.add_field(name="📈 Status", value="Regular Post", inline=True)
        
        # Add top comments
        if performance['comments']:
            comments_text = "\n".join(performance['comments'][:3])  # Show top 3 comments
            if len(comments_text) > 1024:  # Discord field limit
                comments_text = comments_text[:1020] + "..."
            embed.add_field(name="💬 Top Comments", value=comments_text, inline=False)
        
        # Add footer
        embed.set_footer(text="Keep posting to grow your influence! 🚀")
        
        # Send embed response
        await ctx.send(embed=embed)
        
        # Delete the original command message
        try:
            await ctx.message.delete()
        except discord.Forbidden:
            # Bot doesn't have permission to delete messages
            pass
        except discord.NotFound:
            # Message was already deleted
            pass
        finally:
            # Remove from processing set
            bot._processing_commands.discard(ctx.message.id)
    
    @bot.command(name='followers')
    async def followers_command(ctx, member: discord.Member = None):
        # Prevent duplicate processing
        if ctx.message.id in bot._processing_commands:
            return
        bot._processing_commands.add(ctx.message.id)
        """
        Check follower count for yourself or another user.
        
        Usage: !followers [user]
        """
        target_member = member or ctx.author
        user_id = str(target_member.id)
        user_data = data_manager.get_user_data(user_id)
        
        embed = discord.Embed(
            title="👥 Follower Count",
            color=discord.Color.green()
        )
        
        if target_member.avatar:
            embed.set_author(name=target_member.display_name, icon_url=target_member.avatar.url)
        else:
            embed.set_author(name=target_member.display_name)
        
        embed.add_field(name="Followers", value=f"{user_data['followers']:,}", inline=True)
        embed.add_field(name="Total Posts", value=f"{user_data['total_posts']:,}", inline=True)
        embed.add_field(name="Total Likes", value=f"{user_data['total_likes']:,}", inline=True)
        embed.add_field(name="Viral Posts", value=f"{user_data['viral_posts']:,}", inline=True)
        
        # Calculate engagement rate
        if user_data['total_posts'] > 0:
            avg_likes = user_data['total_likes'] // user_data['total_posts']
            embed.add_field(name="Avg Likes/Post", value=f"{avg_likes:,}", inline=True)
        
        # Add mega viral stats (ensure field exists)
        mega_viral_posts = user_data.get('mega_viral_posts', 0)
        if mega_viral_posts > 0:
            embed.add_field(name="🌟 Mega Viral Posts", value=f"{mega_viral_posts:,}", inline=True)
        
        # Calculate viral rate
        if user_data['total_posts'] > 0:
            viral_rate = (user_data['viral_posts'] / user_data['total_posts']) * 100
            embed.add_field(name="Viral Rate", value=f"{viral_rate:.1f}%", inline=True)
        
        try:
            await ctx.send(embed=embed)
        finally:
            # Remove from processing set
            bot._processing_commands.discard(ctx.message.id)
    
    @bot.command(name='topinfluence')
    async def leaderboard_command(ctx):
        # Prevent duplicate processing
        if ctx.message.id in bot._processing_commands:
            return
        bot._processing_commands.add(ctx.message.id)
        """
        Display the top influencers leaderboard.
        
        Usage: !topinfluence
        """
        leaderboard = data_manager.get_leaderboard(10)
        
        if not leaderboard:
            embed = discord.Embed(
                title="🏆 Top Influence Leaderboard",
                description="No users found! Be the first to post something with `!post`",
                color=discord.Color.gold()
            )
            await ctx.send(embed=embed)
            return
        
        embed = discord.Embed(
            title="🏆 Top Influence Leaderboard",
            description="The most influential users in this server!",
            color=discord.Color.gold()
        )
        
        medals = ["🥇", "🥈", "🥉"]
        
        for i, (user_id, user_info) in enumerate(leaderboard, start=1):
            try:
                # Try to get member from current guild, but don't mark as "Left Server"
                member = ctx.guild.get_member(int(user_id))
                if member:
                    # Use display name for better readability
                    name = f"**{member.display_name}**"
                else:
                    # Still show the user but without "Left Server" - they might be in other servers
                    name = f"<@{user_id}>"
            except (ValueError, AttributeError):
                name = f"<@{user_id}>"
            
            # Get medal or rank number
            rank_indicator = medals[i-1] if i <= 3 else f"#{i}"
            
            # Format stats
            followers = f"{user_info['followers']:,}"
            total_likes = f"{user_info['total_likes']:,}"
            posts = f"{user_info['total_posts']:,}"
            viral_posts = f"{user_info['viral_posts']:,}"
            mega_viral_posts = user_info.get('mega_viral_posts', 0)
            
            value = f"👥 **{followers}** followers\n💖 **{total_likes}** total likes\n📝 **{posts}** posts\n🔥 **{viral_posts}** viral posts"
            
            # Add mega viral count if they have any
            if mega_viral_posts > 0:
                value += f"\n🌟 **{mega_viral_posts}** mega viral posts"
            
            embed.add_field(
                name=f"{rank_indicator} {name}",
                value=value,
                inline=False
            )
        
        embed.set_footer(text="Keep posting to climb the leaderboard! 🚀")
        try:
            await ctx.send(embed=embed)
        finally:
            # Remove from processing set
            bot._processing_commands.discard(ctx.message.id)
    
    @bot.command(name='help')
    async def help_command(ctx):
        # Prevent duplicate processing
        if ctx.message.id in bot._processing_commands:
            return
        bot._processing_commands.add(ctx.message.id)
        """
        Show help information for all available commands.
        
        Usage: !help
        """
        embed = discord.Embed(
            title="🤖 Social Media Bot Commands",
            description="Simulate your social media empire!",
            color=discord.Color.blue()
        )
        
        embed.add_field(
            name="📝 !post <content>",
            value="Create a social media post and see how it performs! Gain followers, likes, and maybe go viral!",
            inline=False
        )
        
        embed.add_field(
            name="👥 !followers [user]",
            value="Check follower count and stats for yourself or another user",
            inline=False
        )
        
        embed.add_field(
            name="🏆 !topinfluence",
            value="View the leaderboard of top influencers in this server",
            inline=False
        )
        
        embed.add_field(
            name="🔗 !join <invite_link>",
            value="Generate an invite link for the bot to join a specific Discord server",
            inline=False
        )
        
        embed.add_field(
            name="📋 !commands",
            value="Show detailed command list with usage examples and cooldowns",
            inline=False
        )
        
        embed.add_field(
            name="❓ !help",
            value="Show this help message",
            inline=False
        )
        
        embed.add_field(
            name="✨ Features",
            value="• Realistic engagement simulation\n• Viral post mechanics (5% chance!)\n• Persistent follower tracking\n• Competitive leaderboards\n• Easy server joining",
            inline=False
        )
        
        embed.set_footer(text="Start your social media journey with !post <your content>")
        try:
            await ctx.send(embed=embed)
        finally:
            # Remove from processing set
            bot._processing_commands.discard(ctx.message.id)
    
    @bot.command(name='stats')
    async def stats_command(ctx):
        # Prevent duplicate processing
        if ctx.message.id in bot._processing_commands:
            return
        bot._processing_commands.add(ctx.message.id)
        """
        Show overall bot statistics.
        
        Usage: !stats
        """
        total_posts = data_manager.get_total_posts()
        total_users = len(data_manager.data["users"])
        
        # Calculate total metrics
        total_likes = sum(post["likes"] for post in data_manager.data["posts"].values())
        total_shares = sum(post["shares"] for post in data_manager.data["posts"].values())
        viral_posts = sum(1 for post in data_manager.data["posts"].values() if post.get("viral", False))
        mega_viral_posts = sum(1 for post in data_manager.data["posts"].values() if post.get("mega_viral", False))
        
        embed = discord.Embed(
            title="📊 Bot Statistics",
            color=discord.Color.purple()
        )
        
        embed.add_field(name="👥 Active Users", value=f"{total_users:,}", inline=True)
        embed.add_field(name="📝 Total Posts", value=f"{total_posts:,}", inline=True)
        embed.add_field(name="🔥 Viral Posts", value=f"{viral_posts:,}", inline=True)
        embed.add_field(name="💖 Total Likes", value=f"{total_likes:,}", inline=True)
        embed.add_field(name="🔄 Total Shares", value=f"{total_shares:,}", inline=True)
        
        if total_posts > 0:
            viral_rate = (viral_posts / total_posts) * 100
            embed.add_field(name="🎯 Viral Rate", value=f"{viral_rate:.1f}%", inline=True)
        
        try:
            await ctx.send(embed=embed)
        finally:
            # Remove from processing set
            bot._processing_commands.discard(ctx.message.id)
    
    @bot.command(name='commands')
    async def commands_command(ctx):
        # Prevent duplicate processing
        if ctx.message.id in bot._processing_commands:
            return
        bot._processing_commands.add(ctx.message.id)
        """
        Show detailed information about all bot commands.
        
        Usage: !commands
        """
        embed = discord.Embed(
            title="📋 Detailed Command List",
            description="Complete list of available commands with usage examples",
            color=discord.Color.purple()
        )
        
        commands_info = [
            {
                "name": "!post <content>",
                "description": "Create and simulate a social media post",
                "usage": "`!post Just had the best day ever! 🌟`",
                "cooldown": "3 seconds per user"
            },
            {
                "name": "!followers [user]",
                "description": "View detailed follower statistics",
                "usage": "`!followers` or `!followers @someone`",
                "cooldown": "None"
            },
            {
                "name": "!topinfluence",
                "description": "View server leaderboard of top influencers",
                "usage": "`!topinfluence`",
                "cooldown": "None"
            },
            {
                "name": "!join <invite_link>",
                "description": "Generate bot invite for specific server",
                "usage": "`!join https://discord.gg/ABC123`",
                "cooldown": "None"
            },
            {
                "name": "!stats",
                "description": "View overall bot statistics",
                "usage": "`!stats`",
                "cooldown": "None"
            },
            {
                "name": "!commands",
                "description": "Show this detailed command list",
                "usage": "`!commands`",
                "cooldown": "None"
            },
            {
                "name": "!help",
                "description": "Show basic help information",
                "usage": "`!help`",
                "cooldown": "None"
            }
        ]
        
        for i, cmd in enumerate(commands_info, 1):
            embed.add_field(
                name=f"{i}. {cmd['name']}",
                value=f"**Description:** {cmd['description']}\n**Usage:** {cmd['usage']}\n**Cooldown:** {cmd['cooldown']}",
                inline=False
            )
        
        embed.add_field(
            name="💾 Data Storage",
            value="• All data is stored locally in JSON files\n• Followers & likes persist across restarts\n• Data is saved after every post\n• Leaderboards are real-time",
            inline=False
        )
        
        embed.set_footer(text="Use !help for a quick overview | Data is persistent!")
        try:
            await ctx.send(embed=embed)
        finally:
            # Remove from processing set
            bot._processing_commands.discard(ctx.message.id)
    
    @bot.command(name='join')
    async def join_server_command(ctx, invite_link: str):
        # Prevent duplicate processing
        if ctx.message.id in bot._processing_commands:
            return
        bot._processing_commands.add(ctx.message.id)
        """
        Generate an invite link for the bot to join a specific server.
        
        Usage: !join <discord_invite_link>
        """
        # Extract invite code from various Discord invite formats
        invite_patterns = [
            r'discord\.gg/([a-zA-Z0-9]+)',
            r'discord\.com/invite/([a-zA-Z0-9]+)',
            r'discordapp\.com/invite/([a-zA-Z0-9]+)'
        ]
        
        invite_code = None
        for pattern in invite_patterns:
            match = re.search(pattern, invite_link)
            if match:
                invite_code = match.group(1)
                break
        
        if not invite_code:
            embed = discord.Embed(
                title="❌ Invalid Invite Link",
                description="Please provide a valid Discord invite link.\n\nExamples:\n• `https://discord.gg/ABC123`\n• `https://discord.com/invite/ABC123`",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
        
        # Get bot's client ID from the environment or bot user
        client_id = os.getenv('DISCORD_CLIENT_ID', str(ctx.bot.user.id))
        
        # Generate OAuth2 invite URL with proper permissions
        permissions = discord.Permissions(
            send_messages=True,
            read_messages=True,
            read_message_history=True,
            use_external_emojis=True,
            embed_links=True,
            attach_files=True,
            add_reactions=True
        )
        
        oauth_url = f"https://discord.com/api/oauth2/authorize?client_id={client_id}&permissions={permissions.value}&scope=bot%20applications.commands&guild_id="
        
        try:
            # Try to get invite info (this requires the bot to have access)
            invite = await ctx.bot.fetch_invite(invite_code)
            guild_name = invite.guild.name
            guild_id = invite.guild.id
            member_count = invite.approximate_member_count
            
            final_url = f"{oauth_url}{guild_id}"
            
            embed = discord.Embed(
                title="🤖 Bot Invite Link Generated!",
                description=f"Click the link below to invite me to **{guild_name}**",
                color=discord.Color.green()
            )
            
            embed.add_field(name="🔗 Invite Link", value=f"[Click here to invite bot]({final_url})", inline=False)
            embed.add_field(name="🏠 Server", value=guild_name, inline=True)
            embed.add_field(name="👥 Members", value=f"~{member_count:,}" if member_count else "Unknown", inline=True)
            embed.add_field(name="📋 Instructions", 
                           value="1. Click the invite link above\n2. Select the server from dropdown\n3. Review permissions\n4. Click 'Authorize'", 
                           inline=False)
            embed.set_footer(text="You need 'Manage Server' permission to invite bots!")
            
        except discord.NotFound:
            # Invite is invalid or expired
            embed = discord.Embed(
                title="❌ Invalid or Expired Invite",
                description="The invite link you provided is invalid or has expired.",
                color=discord.Color.red()
            )
            
        except discord.Forbidden:
            # Bot doesn't have permission to fetch invite info
            final_url = oauth_url  # Without guild_id, user will need to select manually
            
            embed = discord.Embed(
                title="🤖 Bot Invite Link Generated!",
                description="I couldn't fetch server details, but here's the invite link:",
                color=discord.Color.orange()
            )
            
            embed.add_field(name="🔗 Invite Link", value=f"[Click here to invite bot]({final_url})", inline=False)
            embed.add_field(name="📋 Instructions", 
                           value="1. Click the invite link above\n2. Select your server from dropdown\n3. Review permissions\n4. Click 'Authorize'", 
                           inline=False)
            embed.set_footer(text="You need 'Manage Server' permission to invite bots!")
            
        except Exception as e:
            # Generic fallback
            final_url = oauth_url
            
            embed = discord.Embed(
                title="🤖 Bot Invite Link",
                description="Here's the invite link (couldn't fetch server details):",
                color=discord.Color.blue()
            )
            
            embed.add_field(name="🔗 Invite Link", value=f"[Click here to invite bot]({final_url})", inline=False)
            embed.add_field(name="📋 Instructions", 
                           value="1. Click the invite link\n2. Select your server\n3. Review permissions\n4. Click 'Authorize'", 
                           inline=False)
            
        try:
            await ctx.send(embed=embed)
        finally:
            # Remove from processing set
            bot._processing_commands.discard(ctx.message.id)
