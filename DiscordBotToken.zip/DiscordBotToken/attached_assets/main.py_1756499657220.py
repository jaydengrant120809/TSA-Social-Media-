"""
Discord Social Media Simulation Bot
Main entry point that initializes and runs the bot with keep-alive functionality.
"""

import os
import discord
from discord.ext import commands
from keep_alive import keep_alive
from config import Config
from bot_commands import setup_commands

def main():
    """Initialize and run the Discord bot."""
    
    # Start keep-alive server
    keep_alive()
    
    # Configure bot intents
    intents = discord.Intents.default()
    intents.message_content = True
    intents.messages = True
    intents.guilds = True
    
    # Create bot instance with additional settings to prevent duplicates
    bot = commands.Bot(
        command_prefix=Config.COMMAND_PREFIX,
        intents=intents,
        help_command=None,  # We'll create a custom help command
        case_insensitive=True,
        strip_after_prefix=True
    )
    
    @bot.event
    async def on_ready():
        """Event triggered when bot successfully connects to Discord."""
        print(f'{bot.user} has connected to Discord!')
        print(f'Bot is in {len(bot.guilds)} guilds')
        
        # Set bot status to online with activity
        activity = discord.Activity(
            type=discord.ActivityType.watching,
            name="your social media empire grow! Use !post to start"
        )
        await bot.change_presence(
            status=discord.Status.online,
            activity=activity
        )
    
    @bot.event
    async def on_command_error(ctx, error):
        """Global error handler for bot commands."""
        if isinstance(error, commands.CommandNotFound):
            await ctx.send("❌ Command not found. Use `!help` to see available commands.")
        elif isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(f"❌ Missing required argument: {error.param}")
        elif isinstance(error, commands.BadArgument):
            await ctx.send("❌ Invalid argument provided.")
        elif isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"⏱️ Slow down! You can use this command again in {error.retry_after:.1f} seconds.")
        else:
            print(f"Unexpected error: {error}")
            await ctx.send("❌ An unexpected error occurred. Please try again.")
    
    # Clear any existing commands to prevent duplicates
    bot.remove_command('help')  # Remove default help command
    
    # Add processing flag to prevent command duplication
    bot._processing_commands = set()
    
    # Setup all bot commands once
    setup_commands(bot)
    
    # Run the bot
    try:
        bot.run(Config.DISCORD_TOKEN)
    except discord.LoginFailure:
        print("ERROR: Invalid Discord token. Please check your DISCORD_TOKEN environment variable.")
    except Exception as e:
        print(f"ERROR: Failed to start bot: {e}")

if __name__ == "__main__":
    main()
