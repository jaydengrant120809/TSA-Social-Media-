"""
Data management system for persistent storage of user data and posts.
Handles JSON file operations and data validation.
"""

import json
import os
from typing import Dict, Any
from config import Config

class DataManager:
    """Manages persistent data storage for the social media simulation."""
    
    def __init__(self):
        """Initialize the data manager and load existing data."""
        self.data = self._load_data()
    
    def _load_data(self) -> Dict[str, Any]:
        """Load data from JSON file or create default structure."""
        if os.path.exists(Config.DATA_FILE):
            try:
                with open(Config.DATA_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    # Ensure required keys exist
                    if "users" not in data:
                        data["users"] = {}
                    if "posts" not in data:
                        data["posts"] = {}
                    return data
            except (json.JSONDecodeError, IOError) as e:
                print(f"⚠️ Error loading data file: {e}. Creating new data structure.")
                return {"users": {}, "posts": {}}
        else:
            return {"users": {}, "posts": {}}
    
    def save_data(self) -> bool:
        """Save data to JSON file."""
        try:
            # Ensure directory exists
            os.makedirs(os.path.dirname(Config.DATA_FILE), exist_ok=True)
            with open(Config.DATA_FILE, "w", encoding="utf-8") as f:
                json.dump(self.data, f, indent=4, ensure_ascii=False)
            print(f"✅ Data saved successfully to {Config.DATA_FILE}")
            return True
        except IOError as e:
            print(f"❌ Error saving data: {e}")
            return False
    
    def get_user_data(self, user_id: str) -> Dict[str, Any]:
        """Get user data, creating default if doesn't exist."""
        if user_id not in self.data["users"]:
            self.data["users"][user_id] = {
                "followers": 0,
                "total_likes": 0,
                "total_posts": 0,
                "viral_posts": 0,
                "mega_viral_posts": 0,
                "joined_timestamp": None
            }
        return self.data["users"][user_id]
    
    def update_user_stats(self, user_id: str, followers_gain: int, likes: int, viral_type: str):
        """Update user statistics after posting."""
        user_data = self.get_user_data(user_id)
        user_data["followers"] += followers_gain
        user_data["total_likes"] += likes
        user_data["total_posts"] += 1
        
        # Ensure mega_viral_posts exists (for backward compatibility)
        if "mega_viral_posts" not in user_data:
            user_data["mega_viral_posts"] = 0
            
        if viral_type == "mega_viral":
            user_data["mega_viral_posts"] += 1
            user_data["viral_posts"] += 1  # Mega viral counts as viral too
        elif viral_type == "viral":
            user_data["viral_posts"] += 1
    
    def create_post(self, post_id: str, author_id: str, content: str, 
                   likes: int, shares: int, comments: list, rating: float, 
                   followers_gain: int, viral_type: str) -> Dict[str, Any]:
        """Create a new post entry."""
        post_data = {
            "author": author_id,
            "content": content,
            "likes": likes,
            "shares": shares,
            "comments": comments,
            "rating": rating,
            "followers_gain": followers_gain,
            "viral_type": viral_type,
            "viral": viral_type != "regular",  # Backward compatibility
            "mega_viral": viral_type == "mega_viral",
            "timestamp": None  # Could add timestamp if needed
        }
        
        self.data["posts"][post_id] = post_data
        self.update_user_stats(author_id, followers_gain, likes, viral_type)
        return post_data
    
    def get_leaderboard(self, limit: int = 10) -> list:
        """Get leaderboard sorted by followers."""
        return sorted(
            self.data["users"].items(),
            key=lambda x: x[1]["followers"],
            reverse=True
        )[:limit]
    
    def get_user_posts(self, user_id: str) -> list:
        """Get all posts by a specific user."""
        return [
            (post_id, post_data)
            for post_id, post_data in self.data["posts"].items()
            if post_data["author"] == user_id
        ]
    
    def get_total_posts(self) -> int:
        """Get total number of posts."""
        return len(self.data["posts"])
