"""
Discord bot commands for the social media simulation.
Contains all user-facing commands and their implementations.
"""

import discord
from discord.ext import commands
import re
import os
from data_manager import DataManager
from social_simulator import SocialSimulator
from config import Config

# Initialize data manager
data_manager = DataManager()

# Global flag to prevent duplicate setups
_commands_registered = False

def check_allowed_guild(ctx):
    """Check if the command is being used in the allowed server."""
    return ctx.guild.id == Config.ALLOWED_GUILD_ID

def setup_commands(bot):
    """Setup all bot commands."""
    global _commands_registered
    
    # Prevent duplicate command registration
    if _commands_registered:
        print("Commands already registered, skipping...")
        return
    
    print("Registering bot commands...")
    _commands_registered = True
    
    @bot.command(name='post')
    @commands.cooldown(1, 3, commands.BucketType.user)  # 1 use per 3 seconds per user
    async def post_command(ctx, *, content):
        """
        Create a social media post and simulate its performance.
        
        Usage: !post <your content here>
        """
        # Prevent duplicate processing
        if ctx.message.id in bot._processing_commands:
            return
        bot._processing_commands.add(ctx.message.id)
        
        try:
            # Check if post command is in allowed server
            if not check_allowed_guild(ctx):
                await ctx.message.delete()
                return
            if len(content) > 2000:
                error_msg = await ctx.send("❌ Post content is too long! Please keep it under 2000 characters.")
                try:
                    await ctx.message.delete()
                    await error_msg.delete(delay=5)
                except (discord.Forbidden, discord.NotFound):
                    pass
                return
            
            if len(content.strip()) < 5:
                error_msg = await ctx.send("❌ Your post is too short! Please write at least 5 characters.")
                try:
                    await ctx.message.delete()
                    await error_msg.delete(delay=5)
                except (discord.Forbidden, discord.NotFound):
                    pass
                return
            
            user_id = str(ctx.author.id)
            post_id = str(data_manager.get_total_posts() + 1)
            
            # Get current user data
            user_data = data_manager.get_user_data(user_id)
            current_followers = user_data["followers"]
            
            # Simulate post performance
            performance = SocialSimulator.simulate_post_performance(content, current_followers, user_id)
            
            # Create post in database
            post_data = data_manager.create_post(
                post_id=post_id,
                author_id=user_id,
                content=content,
                likes=performance['likes'],
                shares=performance['shares'],
                comments=performance['comments'],
                rating=performance['rating'],
                followers_gain=performance['followers_gain'],
                viral_type=performance['viral_type']
            )
            
            # Save data - ensure this always works
            if not data_manager.save_data():
                error_msg = await ctx.send("⚠️ Warning: Could not save your post data.")
                try:
                    await ctx.message.delete()
                    await error_msg.delete(delay=5)
                except (discord.Forbidden, discord.NotFound):
                    pass
                return
            
            # Create embed response with different colors and titles for viral types
            if performance['viral_type'] == 'mega_viral':
                embed_color = discord.Color.purple()
                title_suffix = " 🌟 MEGA VIRAL! 🌟"
            elif performance['viral_type'] == 'viral':
                embed_color = discord.Color.red()
                title_suffix = " 🔥 VIRAL!"
            else:
                embed_color = discord.Color.blue()
                title_suffix = ""
            
            embed = discord.Embed(
                title=f"📱 Your Post{title_suffix}",
                description=f"*{content[:1500]}{'...' if len(content) > 1500 else ''}*",
                color=embed_color
            )
            
            # Set author with avatar
            if ctx.author.avatar:
                embed.set_author(name=ctx.author.display_name, icon_url=ctx.author.avatar.url)
            else:
                embed.set_author(name=ctx.author.display_name)
            
            # Add performance metrics
            embed.add_field(name="📊 Post Rating", value=f"{performance['rating']}/1.0", inline=True)
            embed.add_field(name="👍 Likes", value=f"{performance['likes']:,}", inline=True)
            embed.add_field(name="🔄 Shares", value=f"{performance['shares']:,}", inline=True)
            
            # Add followers info
            new_total = user_data["followers"]
            embed.add_field(name="👥 Followers Gained", value=f"+{performance['followers_gain']:,}", inline=True)
            embed.add_field(name="👥 Total Followers", value=f"{new_total:,}", inline=True)
            
            # Add viral indicator
            if performance['viral_type'] == 'mega_viral':
                embed.add_field(name="🌟 Status", value="**MEGA VIRAL POST!**\n*Ultra rare! 0.2% chance!*", inline=True)
            elif performance['viral_type'] == 'viral':
                embed.add_field(name="🔥 Status", value="**VIRAL POST!**\n*Rare! 2% chance!*", inline=True)
            else:
                embed.add_field(name="📈 Status", value="Regular Post", inline=True)
            
            # Add top comments
            if performance['comments']:
                comments_text = "\n".join(performance['comments'][:3])  # Show top 3 comments
                if len(comments_text) > 1024:  # Discord field limit
                    comments_text = comments_text[:1020] + "..."
                embed.add_field(name="💬 Top Comments", value=comments_text, inline=False)
            
            # Add footer
            embed.set_footer(text="Keep posting to grow your influence! 🚀")
            
            # Send embed response
            await ctx.send(embed=embed)
            
            # Delete the original command message
            try:
                await ctx.message.delete()
            except (discord.Forbidden, discord.NotFound):
                # Bot doesn't have permission to delete messages or message was already deleted
                pass
                
        finally:
            # Remove from processing set
            bot._processing_commands.discard(ctx.message.id)
    
    @bot.command(name='followers')
    async def followers_command(ctx, member: discord.Member = None):
        """
        Check follower count for yourself or another user.
        
        Usage: !followers [user]
        """
        # Prevent duplicate processing
        if ctx.message.id in bot._processing_commands:
            return
        bot._processing_commands.add(ctx.message.id)
        try:
            target_member = member or ctx.author
            user_id = str(target_member.id)
            user_data = data_manager.get_user_data(user_id)
            
            embed = discord.Embed(
                title="👥 Follower Count",
                color=discord.Color.green()
            )
            
            if target_member.avatar:
                embed.set_author(name=target_member.display_name, icon_url=target_member.avatar.url)
            else:
                embed.set_author(name=target_member.display_name)
            
            embed.add_field(name="Followers", value=f"{user_data['followers']:,}", inline=True)
            embed.add_field(name="Total Posts", value=f"{user_data['total_posts']:,}", inline=True)
            embed.add_field(name="Total Likes", value=f"{user_data['total_likes']:,}", inline=True)
            embed.add_field(name="Viral Posts", value=f"{user_data['viral_posts']:,}", inline=True)
            
            # Calculate engagement rate
            if user_data['total_posts'] > 0:
                avg_likes = user_data['total_likes'] // user_data['total_posts']
                embed.add_field(name="Avg Likes/Post", value=f"{avg_likes:,}", inline=True)
            
            # Add mega viral stats (ensure field exists)
            mega_viral_posts = user_data.get('mega_viral_posts', 0)
            if mega_viral_posts > 0:
                embed.add_field(name="🌟 Mega Viral Posts", value=f"{mega_viral_posts:,}", inline=True)
            
            # Calculate viral rate
            if user_data['total_posts'] > 0:
                viral_rate = (user_data['viral_posts'] / user_data['total_posts']) * 100
                embed.add_field(name="Viral Rate", value=f"{viral_rate:.1f}%", inline=True)
            
            await ctx.send(embed=embed)
            
            # Delete the original command message
            try:
                await ctx.message.delete()
            except (discord.Forbidden, discord.NotFound):
                pass
                
        finally:
            # Remove from processing set
            bot._processing_commands.discard(ctx.message.id)
    
    @bot.command(name='topinfluence')
    async def leaderboard_command(ctx):
        """
        Display the top influencers leaderboard.
        
        Usage: !topinfluence
        """
        # Prevent duplicate processing
        if ctx.message.id in bot._processing_commands:
            return
        bot._processing_commands.add(ctx.message.id)
        try:
            leaderboard = data_manager.get_leaderboard(10)
            
            if not leaderboard:
                embed = discord.Embed(
                    title="🏆 Top Influence Leaderboard",
                    description="No users found! Be the first to post something with `!post`",
                    color=discord.Color.gold()
                )
                await ctx.send(embed=embed)
                # Delete the original command message
                try:
                    await ctx.message.delete()
                except (discord.Forbidden, discord.NotFound):
                    pass
                return
            
            embed = discord.Embed(
                title="🏆 Top Influence Leaderboard",
                description="The most influential users in this server!",
                color=discord.Color.gold()
            )
            
            medals = ["🥇", "🥈", "🥉"]
            
            for i, (user_id, user_info) in enumerate(leaderboard, start=1):
                try:
                    # Try to get member from current guild
                    member = ctx.guild.get_member(int(user_id))
                    if member:
                        # Use display name for better readability
                        name = f"**{member.display_name}**"
                    else:
                        # Still show the user but without "Left Server"
                        name = f"<@{user_id}>"
                except (ValueError, AttributeError):
                    name = f"<@{user_id}>"
                
                # Get medal or rank number
                rank_indicator = medals[i-1] if i <= 3 else f"#{i}"
                
                # Format stats
                followers = f"{user_info['followers']:,}"
                total_likes = f"{user_info['total_likes']:,}"
                posts = f"{user_info['total_posts']:,}"
                viral_posts = f"{user_info['viral_posts']:,}"
                mega_viral_posts = user_info.get('mega_viral_posts', 0)
                
                value = f"👥 **{followers}** followers\n💖 **{total_likes}** total likes\n📝 **{posts}** posts\n🔥 **{viral_posts}** viral posts"
                
                # Add mega viral count if they have any
                if mega_viral_posts > 0:
                    value += f"\n🌟 **{mega_viral_posts}** mega viral posts"
                
                embed.add_field(
                    name=f"{rank_indicator} {name}",
                    value=value,
                    inline=False
                )
            
            embed.set_footer(text="Keep posting to climb the leaderboard! 🚀")
            await ctx.send(embed=embed)
            
            # Delete the original command message
            try:
                await ctx.message.delete()
            except (discord.Forbidden, discord.NotFound):
                pass
                
        finally:
            # Remove from processing set
            bot._processing_commands.discard(ctx.message.id)
    
    @bot.command(name='help')
    async def help_command(ctx):
        """
        Show help information for all available commands.
        
        Usage: !help
        """
        # Prevent duplicate processing
        if ctx.message.id in bot._processing_commands:
            return
        bot._processing_commands.add(ctx.message.id)
        try:
            embed = discord.Embed(
                title="🤖 Social Media Bot Commands",
                description="Simulate your social media empire!",
                color=discord.Color.blue()
            )
            
            embed.add_field(
                name="📝 !post <content>",
                value="Create a social media post and see how it performs! Gain followers, likes, and maybe go viral!",
                inline=False
            )
            
            embed.add_field(
                name="👥 !followers [user]",
                value="Check follower count and stats for yourself or another user",
                inline=False
            )
            
            embed.add_field(
                name="🏆 !topinfluence",
                value="View the leaderboard of top influencers in this server",
                inline=False
            )
            
            embed.add_field(
                name="❓ !help",
                value="Show this help message",
                inline=False
            )
            
            embed.add_field(
                name="✨ Features",
                value="• Realistic engagement simulation\n• Viral post mechanics (2% chance!)\n• Mega viral posts (0.2% chance!)\n• Persistent follower tracking\n• Competitive leaderboards",
                inline=False
            )
            
            embed.set_footer(text="Start your social media journey with !post <your content>")
            await ctx.send(embed=embed)
            
            # Delete the original command message
            try:
                await ctx.message.delete()
            except (discord.Forbidden, discord.NotFound):
                pass
                
        finally:
            # Remove from processing set
            bot._processing_commands.discard(ctx.message.id)
    
    @bot.command(name='invite')
    async def invite_command(ctx):
        """Generate an invite link for the bot."""
        if ctx.message.id in bot._processing_commands:
            return
        bot._processing_commands.add(ctx.message.id)
        
        try:
            # Bot permissions needed: Send Messages, Embed Links, Manage Messages, Read Message History
            permissions = discord.Permissions(
                send_messages=True,
                embed_links=True,
                manage_messages=True,
                read_message_history=True,
                use_slash_commands=True
            )
            
            invite_url = discord.utils.oauth_url(bot.user.id, permissions=permissions)
            
            embed = discord.Embed(
                title="🔗 Invite Social Media Bot",
                description="Add this bot to your server!",
                color=discord.Color.green()
            )
            
            embed.add_field(
                name="Invite Link",
                value=f"[Click here to invite the bot]({invite_url})",
                inline=False
            )
            
            embed.add_field(
                name="Required Permissions",
                value="• Send Messages\n• Embed Links\n• Manage Messages\n• Read Message History",
                inline=False
            )
            
            await ctx.send(embed=embed)
            
            # Delete the original command message
            try:
                await ctx.message.delete()
            except (discord.Forbidden, discord.NotFound):
                pass
                
        finally:
            bot._processing_commands.discard(ctx.message.id)
    
    print("✅ All bot commands registered successfully!")
