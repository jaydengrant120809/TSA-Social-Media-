"""
Social media simulation engine that generates realistic engagement metrics,
viral content mechanics, and follower growth algorithms.
"""

import random
import math
from typing import Tuple, List

class SocialSimulator:
    """Simulates social media engagement and viral mechanics."""
    
    # Sample comments for post engagement simulation
    SAMPLE_COMMENTS = [
        "This is absolutely incredible! 🔥",
        "I totally agree with this perspective!",
        "Really makes you think... 🤔",
        "Not convinced about this tbh",
        "🔥🔥🔥 FIRE POST!",
        "Love this content!",
        "Could be better imo",
        "This is exactly what I needed to see today",
        "LOL this made my day 😂",
        "So true! Sharing this everywhere",
        "Mind = blown 🤯",
        "Absolutely brilliant!",
        "This needs way more attention!",
        "LEGENDARY content right here!",
        "This is insane! How did you come up with this?",
        "Wow, just wow... speechless",
        "Finally someone said it!",
        "This hits different 💯",
        "Pure gold! 🏆",
        "Can't stop thinking about this"
    ]
    
    # Sample usernames for comment generation
    SAMPLE_USERNAMES = [
        "TechGuru2024", "ViralHunter99", "ContentKing", "DailyInfluencer",
        "TrendMaster", "HistoryNerd", "CoolVibes123", "PhilosophyDeep",
        "ViralQueen", "GamerLegend", "CreativeGenius", "ThoughtLeader",
        "IdeaMachine", "TrendSetter", "ContentCreator", "DigitalNomad",
        "InnovatorX", "FutureThinker", "WisdomSeeker", "ImpactMaker"
    ]
    
    @staticmethod
    def rate_post_quality(content: str) -> float:
        """
        Rate post quality based on content analysis.
        Returns a rating between 0.1 and 1.0.
        """
        # Base score from content length (longer posts tend to perform better)
        length_score = min(len(content) / 200, 0.7)  # Max 0.7 from length
        
        # Bonus for certain keywords that tend to perform well
        viral_keywords = [
            'amazing', 'incredible', 'wow', 'unbelievable', 'shocking',
            'mind-blowing', 'revolutionary', 'game-changer', 'breakthrough',
            'exclusive', 'secret', 'viral', 'trending', 'epic'
        ]
        
        keyword_bonus = 0
        content_lower = content.lower()
        for keyword in viral_keywords:
            if keyword in content_lower:
                keyword_bonus += 0.05  # Small bonus per viral keyword
        
        keyword_bonus = min(keyword_bonus, 0.2)  # Cap at 0.2
        
        # Random factor to simulate unpredictable viral nature
        random_factor = random.uniform(0.1, 0.3)
        
        # Calculate final rating
        rating = length_score + keyword_bonus + random_factor
        return round(min(rating, 1.0), 2)  # Cap at 1.0 and round
    
    @staticmethod
    def calculate_engagement(rating: float, base_followers: int, viral_type: str) -> Tuple[int, int, int]:
        """
        Calculate engagement metrics (likes, shares, followers_gain) based on post quality.
        
        Args:
            rating: Post quality rating (0.1 - 1.0)
            base_followers: Current follower count
            viral_type: 'regular', 'viral', or 'mega_viral'
            
        Returns:
            Tuple of (likes, shares, followers_gain)
        """
        if viral_type == 'mega_viral':
            # MEGA VIRAL posts get MASSIVE engagement
            followers_gain = random.randint(500000, 1000000)  # 500K-1M followers
            likes = random.randint(25000000, 50000000)  # 25M-50M likes
            shares = random.randint(5000000, 10000000)  # 5M-10M shares
        elif viral_type == 'viral':
            # Regular viral posts get big engagement
            followers_gain = random.randint(50000, 100000)  # 50K-100K followers
            likes = random.randint(2500000, 5000000)  # 2.5M-5M likes
            shares = random.randint(500000, 1000000)  # 500K-1M shares
        else:
            # Regular posts scale with quality and current follower count
            base_engagement = int(rating * 1000)
            follower_multiplier = max(1, base_followers // 1000)  # More followers = more engagement
            
            followers_gain = random.randint(
                int(base_engagement * 0.5),
                int(base_engagement * 2 * follower_multiplier)
            )
            
            # Likes are typically 2-10x the follower gain
            likes = random.randint(
                followers_gain * 2,
                min(followers_gain * 10, 500000)
            )
            
            # Shares are typically 10-30% of likes
            shares = random.randint(
                int(likes * 0.1),
                int(likes * 0.3)
            )
            
            # Cap followers gain for regular posts
            followers_gain = min(followers_gain, 50000)
        
        return likes, shares, followers_gain
    
    @staticmethod
    def check_viral_potential(rating: float, user_id: str = None) -> str:
        """
        Determine viral type based on quality and random chance.
        Returns 'regular', 'viral', or 'mega_viral'
        """
        # Special user with 50% viral chances
        special_user = "744584623216001084"
        
        if user_id == special_user:
            # Special user gets 50% chance for both viral types
            if random.random() < 0.5:  # 50% chance for mega viral
                return 'mega_viral'
            elif random.random() < 0.5:  # 50% chance for regular viral
                return 'viral'
        else:
            # Normal users get standard chances
            # Check for MEGA VIRAL first (rarest)
            mega_viral_chance = 0.002  # 0.2% base chance
            quality_bonus = rating * 0.001  # Up to 0.1% bonus for perfect posts
            if random.random() < (mega_viral_chance + quality_bonus):
                return 'mega_viral'
            
            # Check for regular VIRAL
            viral_chance = 0.02  # 2% base chance
            quality_bonus = rating * 0.01  # Up to 1% bonus for perfect posts
            if random.random() < (viral_chance + quality_bonus):
                return 'viral'
        
        # Otherwise regular post
        return 'regular'
    
    @staticmethod
    def generate_comments(num_comments: int = None) -> List[str]:
        """Generate realistic comments with usernames."""
        if num_comments is None:
            num_comments = random.randint(1, 8)  # Variable comment count
        
        comments_with_users = []
        used_usernames = set()
        
        for _ in range(num_comments):
            # Ensure unique usernames in comments
            available_usernames = [u for u in SocialSimulator.SAMPLE_USERNAMES if u not in used_usernames]
            if not available_usernames:
                break  # No more unique usernames available
                
            username = random.choice(available_usernames)
            used_usernames.add(username)
            comment = random.choice(SocialSimulator.SAMPLE_COMMENTS)
            comments_with_users.append(f"@{username}: {comment}")
        
        return comments_with_users
    
    @staticmethod
    def simulate_post_performance(content: str, current_followers: int, user_id: str = None) -> dict:
        """
        Main function to simulate complete post performance.
        
        Returns a dictionary with all engagement metrics.
        """
        # Analyze post quality
        rating = SocialSimulator.rate_post_quality(content)
        
        # Check viral type
        viral_type = SocialSimulator.check_viral_potential(rating, user_id)
        
        # Calculate engagement metrics
        likes, shares, followers_gain = SocialSimulator.calculate_engagement(
            rating, current_followers, viral_type
        )
        
        # Generate comments (more for viral posts)
        if viral_type == 'mega_viral':
            comments = SocialSimulator.generate_comments(8)  # More comments for mega viral
        elif viral_type == 'viral':
            comments = SocialSimulator.generate_comments(6)  # More comments for viral
        else:
            comments = SocialSimulator.generate_comments()  # Regular amount
        
        return {
            'rating': rating,
            'viral_type': viral_type,
            'is_viral': viral_type != 'regular',  # Backward compatibility
            'is_mega_viral': viral_type == 'mega_viral',
            'likes': likes,
            'shares': shares,
            'followers_gain': followers_gain,
            'comments': comments
        }
