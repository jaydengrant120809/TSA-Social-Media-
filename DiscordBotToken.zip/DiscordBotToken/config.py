"""
Configuration settings for the Discord Social Media Simulation Bot.
Handles environment variables and application settings.
"""

import os

class Config:
    """Configuration class for bot settings."""
    
    # Discord Bot Configuration
    DISCORD_TOKEN = os.getenv("DISCORD_TOKEN", "")
    COMMAND_PREFIX = os.getenv("COMMAND_PREFIX", "!")
    
    # Server Configuration
    ALLOWED_GUILD_ID = int(os.getenv("ALLOWED_GUILD_ID", "1396321343812669440"))  # Only allow commands in this server
    
    # Data Storage Configuration
    DATA_FILE = os.getenv("DATA_FILE", "data/social_data.json")
    
    # Keep-Alive Server Configuration
    KEEP_ALIVE_PORT = int(os.getenv("PORT", 5000))
    KEEP_ALIVE_HOST = "0.0.0.0"
    
    # Bot Settings
    BOT_NAME = "Social Media Simulator"
    BOT_VERSION = "1.0.0"
    
    @classmethod
    def validate_config(cls):
        """Validate required configuration settings."""
        if not cls.DISCORD_TOKEN:
            raise ValueError("DISCORD_TOKEN environment variable is required!")
        
        if len(cls.DISCORD_TOKEN) < 50:
            raise ValueError("DISCORD_TOKEN appears to be invalid (too short)")
        
        print(f"✅ Configuration validated successfully")
        print(f"📁 Data file: {cls.DATA_FILE}")
        print(f"🔧 Command prefix: {cls.COMMAND_PREFIX}")
        print(f"🏠 Allowed server ID: {cls.ALLOWED_GUILD_ID}")
        print(f"🌐 Keep-alive port: {cls.KEEP_ALIVE_PORT}")
