# Discord Social Media Simulation Bot

A Discord bot that simulates social media engagement, allowing users to create posts, gain followers, and potentially go viral! Built with Python and discord.py.

## Features

- 📱 **Create Posts**: Users can create social media posts using `!post <content>`
- 👥 **Follower System**: Track follower counts and growth
- 🔥 **Viral Mechanics**: Posts have a chance to go viral (2%) or mega viral (0.2%)
- 📊 **Engagement Metrics**: Realistic likes, shares, and comments simulation
- 🏆 **Leaderboards**: See top influencers in your server
- 💾 **Persistent Data**: All data is saved and persists across bot restarts

## Commands

- `!post <content>` - Create a social media post
- `!followers [user]` - Check follower count and stats
- `!topinfluence` - View the leaderboard of top influencers
- `!help` - Show all available commands
- `!invite` - Get an invite link for the bot

## Setup

### Prerequisites

- Python 3.8 or higher
- A Discord bot token (from Discord Developer Portal)

### Installation

1. Clone this repository or download the files
2. Install dependencies:
   ```bash
   pip install discord.py flask
   ```

3. Set up environment variables:
   ```bash
   export DISCORD_TOKEN="your_discord_bot_token_here"
   ```

4. Run the bot:
   ```bash
   python main.py
   ```

### Environment Variables

- `DISCORD_TOKEN` - **Required**: Your Discord bot token
- `COMMAND_PREFIX` - Optional: Command prefix (default: `!`)
- `DATA_FILE` - Optional: Path to data file (default: `data/social_data.json`)
- `PORT` - Optional: Port for keep-alive server (default: `5000`)

### Discord Bot Setup

1. Go to the [Discord Developer Portal](https://discord.com/developers/applications)
2. Create a new application and bot
3. Copy the bot token and set it as the `DISCORD_TOKEN` environment variable
4. Invite the bot to your server with the following permissions:
   - Send Messages
   - Embed Links
   - Manage Messages
   - Read Message History

## How It Works

### Post Quality Rating
Posts are rated based on:
- Content length (longer posts tend to perform better)
- Viral keywords (amazing, incredible, wow, etc.)
- Random factor to simulate unpredictable viral nature

### Viral Mechanics
- **Regular Posts**: Normal engagement based on quality and current followers
- **Viral Posts**: 2% chance for significantly boosted engagement (50K-100K followers, 2.5M-5M likes)
- **Mega Viral Posts**: 0.2% chance for massive engagement (500K-1M followers, 25M-50M likes)

### Data Storage
All user data and posts are stored in a JSON file (`data/social_data.json`) and persist across bot restarts.

## Project Structure

