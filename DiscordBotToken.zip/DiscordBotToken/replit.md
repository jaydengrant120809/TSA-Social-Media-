# Discord Social Media Simulation Bot

## Overview

This is a Discord bot that simulates social media engagement mechanics, allowing users to create posts, gain followers, and experience viral content dynamics within Discord servers. The bot provides a gamified social media experience with realistic engagement metrics, follower growth systems, and viral mechanics. Users can create posts using commands, track their follower counts, compete on leaderboards, and watch their content potentially go viral with algorithmically-generated likes, shares, and comments.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Bot Framework Architecture
- **Discord.py Library**: Built on the discord.py framework for Discord API integration
- **Command-Based System**: Uses Discord's command extension system with prefix-based commands (default: `!`)
- **Event-Driven Design**: Implements Discord event handlers for bot lifecycle management and user interactions
- **Modular Command Structure**: Commands are separated into dedicated modules for maintainability

### Data Persistence Layer
- **JSON File Storage**: Uses simple JSON file-based persistence for user data and posts
- **In-Memory Caching**: Data is loaded into memory on startup and periodically saved to disk
- **Default Data Structure**: Maintains separate collections for users and posts with automatic initialization
- **Data Validation**: Implements error handling for corrupted data files with fallback to default structures

### Social Media Simulation Engine
- **Content Quality Rating**: Analyzes post content using length, keywords, and patterns to assign quality scores
- **Viral Mechanics**: Implements probabilistic viral systems (2% normal viral, 0.2% mega viral chance)
- **Engagement Generation**: Creates realistic likes, shares, and comments using weighted random algorithms
- **Follower Growth Simulation**: Calculates follower gains based on post performance and quality ratings
- **Comment Generation**: Uses predefined comment pools with random username assignment for authentic feel

### Keep-Alive Infrastructure
- **Flask Web Server**: Runs a lightweight HTTP server to prevent hosting platform sleep modes
- **Health Check Endpoints**: Provides multiple endpoints for monitoring bot status and uptime
- **Threading Model**: Web server runs in separate thread to avoid blocking Discord bot operations
- **Environment-Based Configuration**: Configurable port and host settings for different deployment environments

### Configuration Management
- **Environment Variable System**: Centralized configuration through environment variables
- **Validation Layer**: Implements configuration validation with clear error messages
- **Default Fallbacks**: Provides sensible defaults for optional configuration parameters
- **Security Practices**: Keeps sensitive tokens in environment variables rather than code

### Error Handling and Resilience
- **Command Cooldowns**: Implements rate limiting to prevent spam and API abuse
- **Duplicate Prevention**: Guards against duplicate command processing and registration
- **Graceful Degradation**: Handles file I/O errors and maintains functionality when possible
- **User Input Validation**: Validates post content length and format before processing

## External Dependencies

### Core Libraries
- **discord.py**: Primary Discord API wrapper for bot functionality and event handling
- **Flask**: Lightweight web framework for keep-alive server and health monitoring endpoints

### Runtime Environment
- **Python 3.8+**: Minimum Python version requirement for modern asyncio and typing support
- **JSON Standard Library**: Built-in JSON module for data serialization and persistence

### Discord Platform Integration
- **Discord Developer Portal**: Requires bot token from Discord's developer platform
- **Discord Gateway API**: Real-time communication with Discord servers through WebSocket connections
- **Discord Intents System**: Uses message content, guild, and member intents for full functionality

### Hosting Platform Compatibility
- **Replit**: Designed to work with Replit's hosting environment and keep-alive requirements
- **Environment Variables**: Supports standard environment variable configuration for cloud deployments
- **Port Binding**: Configurable port binding for various hosting platform requirements